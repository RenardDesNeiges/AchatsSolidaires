<?php
/*
 * Template Name: Good to Be Bad
 * Description: A Page Template with a darker design.
 */

echo 'LA BONNE BITE OUI OUI';
