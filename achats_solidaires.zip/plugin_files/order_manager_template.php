<?php
/*
 * Template Name: Good to Be Bad
 * Description: A Page Template with a darker design.
 */

get_header() ?>


<script type="text/javascript" href="generate_order.js"></script>