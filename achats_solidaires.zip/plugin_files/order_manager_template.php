<?php
/*
 * Template Name: Good to Be Bad
 * Description: A Page Template with a darker design.
 */



wp_enqueue_script('generate_order');

get_header() 
?>

<div id="mainP">THIS IS THE DIV IT IS NICE</div>