
jQuery(document).ready(function($) {
  document.getElementById('mainP').innerHTML = "THIS IS SET BY MY VERY COOL SCRIPT"
});